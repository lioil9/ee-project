package club.banyuan;

import club.banyuan.entity.SysUser;
import club.banyuan.mapper.SysUserMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)    //这个是启用自己配置的数据元，不加则采用虚拟数据源
@Rollback(false)    //这个是默认是回滚，不会commit入数据库，改成false 则commit
public class TestMapper {
    @Autowired
    private SysUserMapper sysUserMapper;

    @Test
    public void testSysUser(){
        List<SysUser> userList = sysUserMapper.selectAll();
        for (SysUser sysUser : userList) {
            System.out.println(sysUser.getRealname());
        }
    }
}
