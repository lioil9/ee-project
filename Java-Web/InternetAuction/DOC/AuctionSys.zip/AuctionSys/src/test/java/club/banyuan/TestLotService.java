package club.banyuan;

import club.banyuan.entity.Lot;
import club.banyuan.service.LotService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TestLotService {
    @Autowired
    private LotService lotService;

    @Test
    public void testAddLot() throws ParseException {
        Lot lot = new Lot();
        lot.setLotname("花鸟画");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date1 =sdf.parse("2020-7-1 0:0:0");
        Date date2 = sdf.parse("2020-8-1 23:59:59");
        lot.setBegintime(date1);
        lot.setEndtime(date2);
        lot.setBeginprice(2000.0);
        lot.setFloorprice(3000.0);

        lot = lotService.add(lot);
        System.out.println(lot.getLotid());

    }
}
