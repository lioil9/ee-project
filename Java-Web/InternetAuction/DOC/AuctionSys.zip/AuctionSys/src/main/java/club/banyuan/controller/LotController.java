package club.banyuan.controller;

import club.banyuan.entity.Lot;
import club.banyuan.service.LotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;

@Controller
public class LotController {
    @Autowired
    private LotService lotService;

    @RequestMapping("/addLotPage")
    public String addLotPage(){
        return "addLot";
    }

    @RequestMapping("/addLot")
    public String add(Lot lot){
        lot = lotService.add(lot);
        return "success";
    }
}
