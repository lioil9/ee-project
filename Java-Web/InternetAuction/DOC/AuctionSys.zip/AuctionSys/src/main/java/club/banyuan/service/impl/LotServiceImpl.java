package club.banyuan.service.impl;

import club.banyuan.entity.Lot;
import club.banyuan.mapper.LotMapper;
import club.banyuan.service.LotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LotServiceImpl implements LotService {
    @Autowired
    public LotMapper lotMapper;
    @Override
    public Lot add(Lot lot) {
        lotMapper.insertUseGeneratedKeys(lot);
        return lot;
    }
}
