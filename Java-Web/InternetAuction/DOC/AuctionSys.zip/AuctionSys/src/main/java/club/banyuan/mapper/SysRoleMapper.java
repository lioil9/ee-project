package club.banyuan.mapper;

import club.banyuan.entity.SysRole;
import club.banyuan.my.mapper.MyMapper;

public interface SysRoleMapper extends MyMapper<SysRole> {
}