package club.banyuan.mapper;

import club.banyuan.entity.Endlot;
import club.banyuan.my.mapper.MyMapper;

public interface EndlotMapper extends MyMapper<Endlot> {
}