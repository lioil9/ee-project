package club.banyuan.mapper;

import club.banyuan.entity.SysPermission;
import club.banyuan.my.mapper.MyMapper;

public interface SysPermissionMapper extends MyMapper<SysPermission> {
}