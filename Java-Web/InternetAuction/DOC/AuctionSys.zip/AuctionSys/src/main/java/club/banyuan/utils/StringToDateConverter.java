package club.banyuan.utils;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class StringToDateConverter implements Converter<String, Date> {

    @Override
    public Date convert(String s) {
        if(StringUtils.isEmpty(s)){
            throw new NullPointerException("s不能为空");
        }
        else{
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            Date date = null;
            try {
                date = sdf1.parse(s);
            } catch (ParseException e) {
                e.printStackTrace();
                throw new RuntimeException("日期格式错误");
            }
            try {
                date = sdf2.parse(s);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return date;
        }
//        return null;
    }
}
