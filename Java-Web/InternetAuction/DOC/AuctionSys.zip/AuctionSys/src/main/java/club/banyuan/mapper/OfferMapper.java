package club.banyuan.mapper;

import club.banyuan.entity.Offer;
import club.banyuan.my.mapper.MyMapper;

public interface OfferMapper extends MyMapper<Offer> {
}