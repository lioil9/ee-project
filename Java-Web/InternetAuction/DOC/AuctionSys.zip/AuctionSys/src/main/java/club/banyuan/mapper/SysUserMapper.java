package club.banyuan.mapper;

import club.banyuan.entity.SysUser;
import club.banyuan.my.mapper.MyMapper;

public interface SysUserMapper extends MyMapper<SysUser> {
}