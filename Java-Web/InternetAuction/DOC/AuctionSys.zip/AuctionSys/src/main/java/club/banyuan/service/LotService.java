package club.banyuan.service;

import club.banyuan.entity.Lot;

public interface LotService {
    public Lot add(Lot lot);
}
