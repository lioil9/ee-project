package club.banyuan.mapper;

import club.banyuan.entity.Lot;
import club.banyuan.my.mapper.MyMapper;

public interface LotMapper extends MyMapper<Lot> {
}