package club.banyuan.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "TestFilter1",value = {"*.do","/folder/*"})
public class TestFilter1 implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        System.out.println("TestFilter1 --- doFilter --- before");
        HttpServletRequest request = (HttpServletRequest)req;
        HttpSession session = request.getSession();
        if(session.getAttribute("sessionAttr")!=null){
            chain.doFilter(req, resp);//转发到原来请求路径
        }
        else{
            request.setAttribute("msg","session没有属性");
            request.getRequestDispatcher("../index.jsp").forward(request,resp);
        }
        System.out.println("TestFilter1 --- doFilter --- after");
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
