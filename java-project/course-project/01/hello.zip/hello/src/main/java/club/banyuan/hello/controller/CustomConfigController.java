package club.banyuan.hello.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import club.banyuan.hello.config.CustomConfig;

@RestController
public class CustomConfigController {

	@Autowired
	private CustomConfig customConfig;

	@RequestMapping("/custom")
	public String custom() {
		return "读取到自定义配置 custom.username 内容为：" + customConfig.getUsername();
	}
}
