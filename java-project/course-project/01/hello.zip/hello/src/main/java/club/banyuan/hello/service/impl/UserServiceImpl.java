package club.banyuan.hello.service.impl;

import org.springframework.stereotype.Service;

import club.banyuan.hello.service.UserService;
import club.banyuan.hello.utils.DateUtil;

@Service
public class UserServiceImpl implements UserService {

	@Override
	public String getCurrentYear() {
		int year = DateUtil.getCurrentYear();
		return String.valueOf(year);
	}

	@Override
	public String getBirthYearByAge(int age) {
		int birthYear = DateUtil.getCurrentYear() - age;
		return String.valueOf(birthYear);
	}

}
