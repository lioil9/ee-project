package club.banyuan.hello.mapper;

import java.util.List;

import club.banyuan.hello.entity.PersonEntity;

public interface PersonMapper {

	public int total();
	
	public PersonEntity getById(Integer id);
	
	public List<PersonEntity> getAll();
	
	public int insert(PersonEntity person);
	
	public int updateById(PersonEntity person);
	
	public int deleteById(Integer id);
}
