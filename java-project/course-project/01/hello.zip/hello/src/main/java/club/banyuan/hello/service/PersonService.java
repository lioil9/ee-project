package club.banyuan.hello.service;

import java.util.List;

import club.banyuan.hello.dto.Person;

public interface PersonService {

	public int total();
	
	public Person getPersonById(Integer id);
	
	public List<Person> getAllPerson();
	
	public boolean insert(Person person);
	
	public boolean updateById(Person person);
	
	public boolean deleteById(Integer id);
}
