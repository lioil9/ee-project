package club.banyuan.hello.service;

public interface UserService {

	public String getCurrentYear();

	public String getBirthYearByAge(int age);
}
