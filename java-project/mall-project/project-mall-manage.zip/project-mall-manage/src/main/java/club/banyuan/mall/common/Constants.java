package club.banyuan.mall.common;

public class Constants {

	public final static String FILE_UPLOAD_DIC = "/Users/edz/workspace/newbee-mall-manage/upload/";
}
