package club.banyuan.mall.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import club.banyuan.mall.dto.GoodsCategory;
import club.banyuan.mall.util.Result;
import club.banyuan.mall.util.ResultGenerator;

@RestController
@RequestMapping("/admin")
public class GoodsCategoryController {

	@GetMapping("/categories/list")
	public Result<?> list(@RequestParam Map<String, Object> params) {
		//
		return ResultGenerator.genSuccessResult();
	}

	@GetMapping("/categories/listForSelect")
	public Result<?> listForSelect(@RequestParam("categoryId") Long categoryId) {
		//
		return ResultGenerator.genSuccessResult();
	}

	@PostMapping("/categories/save")
	public Result<?> save(@RequestBody GoodsCategory goodsCategory) {
		//
		return ResultGenerator.genSuccessResult();
	}

	@PostMapping("/categories/update")
	public Result<?> update(@RequestBody GoodsCategory goodsCategory) {
		//
		return ResultGenerator.genSuccessResult();
	}

	@GetMapping("/categories/info/{id}")
	public Result<?> info(@PathVariable("id") Long id) {
		//
		return ResultGenerator.genSuccessResult();
	}

	@PostMapping("/categories/delete")
	public Result<?> delete(@RequestBody Integer[] ids) {
		//
		return ResultGenerator.genSuccessResult();
	}
}
