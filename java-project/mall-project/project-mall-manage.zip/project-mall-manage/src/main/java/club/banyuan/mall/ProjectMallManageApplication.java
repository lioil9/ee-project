package club.banyuan.mall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectMallManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectMallManageApplication.class, args);
	}

}
