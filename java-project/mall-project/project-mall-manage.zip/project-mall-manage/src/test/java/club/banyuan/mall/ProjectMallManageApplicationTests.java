package club.banyuan.mall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectMallManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
